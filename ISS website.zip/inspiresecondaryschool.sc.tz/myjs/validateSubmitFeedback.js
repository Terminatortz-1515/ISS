
function validateFeedbackForm(){
let x=document.forms["feedbackForm"]["feedbackName"].value;
if(x==""){
alert("NAME IS REQUIRED!");

return false;
}else{
	//$(document).ready(function(){
	//	$("form").submit(function(){
			alert("YOU SUBMITTED");
			return false;
		//});
//});
}
}