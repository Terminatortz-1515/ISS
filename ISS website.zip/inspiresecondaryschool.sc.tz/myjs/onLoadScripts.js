function myScipt() {
	
	var eventshttp = new XMLHttpRequest();
    eventshttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
		  if(this.responseText !=""){
        document.getElementById("picsgallery").innerHTML =this.responseText;
		  var eventsGallery=document.getElementById("picsgallery");
   eventsGallery.style.display="block";
		  }
      }
    };
    eventshttp.open("GET","../admins/eventsGallery.php",true);
    eventshttp.send();
	
	
	
	
	//document.getElementById("latestNews").innerHTML ="NO WAY OUT";  selectNews
   var latesthttp = new XMLHttpRequest();
    latesthttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
		  if(this.responseText !=""){
        document.getElementById("latestNews").innerHTML =this.responseText;
		  var newLink=document.getElementById("latestNews");
   newLink.style.display="block";
		  }
      }
    };
    latesthttp.open("GET","admins/latestNews.php",true);
    latesthttp.send();
	
	
   
   
   var selenewsthttp = new XMLHttpRequest();
    selenewsthttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("selectNews").innerHTML =this.responseText;
		//alert(this.responseText);
      }
    };
    selenewsthttp.open("GET","../admins/allNews.php",true);
    selenewsthttp.send();
	
	
	
	var selecatthttp = new XMLHttpRequest();
    selecatthttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("selectCategory").innerHTML =this.responseText;
		//alert(this.responseText);
      }
    };
    selecatthttp.open("GET","../admins/eventsCategories.php",true);
    selecatthttp.send();
	
	
	var defaultnewsthttp = new XMLHttpRequest();
    defaultnewsthttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("selectNewsDetails").innerHTML =this.responseText;
		//alert(this.responseText);
      }
    };
    defaultnewsthttp.open("GET","../admins/defaultNews.php",true);
    defaultnewsthttp.send(); 
 
 
 
 
  setTimeout(function(){

 var setImgManager=document.querySelector("#imgManager");
 var originalManagerImgWidth=setImgManager.naturalWidth;
 var currentManagerImgWidth=setImgManager.clientWidth;
 var originalManagerImgHeight=setImgManager.naturalHeight;
 var currentManagerImgHeight=setImgManager.clientHeight;
  
 if(parseInt(currentManagerImgHeight) >0){
 if(parseInt(originalManagerImgWidth) >parseInt(originalLiManagerImgHeight)){
	 var ratio=parseInt(originalManagerImgWidth)/parseInt(originalManagerImgHeight);
 
 currentManagerImgHeight=Math.round(parseInt(currentManagerImgWidth)/ratio);
 
 $("#imgManager").css("height",currentManagerImgHeight);
 }else  if(parseInt(originalManagerImgWidth) <parseInt(originalManagerImgHeight)){
	 var ratio=parseInt(originalManagerImgHeight)/parseInt(originalManagerImgWidth);
 
 currentManagerImgHeight=Math.round(parseInt(currentManagerImgWidth)*ratio);
 
 $("#imgManager").css("height",currentManagerImgHeight); 
 }
 }



 var setImgLibrary=document.querySelector("#imgLibrary");
 var originalLibraryImgWidth=setImgLibrary.naturalWidth;
 var currentLibraryImgWidth=setImgLibrary.clientWidth;
 var originalLibraryImgHeight=setImgLibrary.naturalHeight;
 var currentLibraryImgHeight=setImgLibrary.clientHeight;
  
 if(parseInt(currentLibraryImgHeight) >0){
 if(parseInt(originalLibraryImgWidth) >parseInt(originalLibraryImgHeight)){
	 var ratio=parseInt(originalLibraryImgWidth)/parseInt(originalLibraryImgHeight);
 
 currentLibraryImgHeight=Math.round(parseInt(currentLibraryImgWidth)/ratio);
 
 $("#imgLibrary").css("height",currentLibraryImgHeight);
 }else  if(parseInt(originalLibraryImgWidth) <parseInt(originalLibraryImgHeight)){
	 var ratio=parseInt(originalLibraryImgHeight)/parseInt(originalLibraryImgWidth);
 
 currentLibraryImgHeight=Math.round(parseInt(currentLibraryImgWidth)*ratio);
 
 $("#imgLibrary").css("height",currentLibraryImgHeight); 
 }
 }
 
 
 
 var setImgClass=document.querySelector("#imgClass");
 var originalClassImgWidth=setImgClass.naturalWidth;
 var currentClassImgWidth=setImgClass.clientWidth;
 var originalClassImgHeight=setImgClass.naturalHeight;
 var currentClassImgHeight=setImgClass.clientHeight;
  
 if(parseInt(currentClassImgHeight) >0){
 if(parseInt(originalClassImgWidth) >parseInt(originalClassImgHeight)){
	 var ratio=parseInt(originalClassImgWidth)/parseInt(originalClassImgHeight);
 
 currentClassImgHeight=Math.round(parseInt(currentClassImgWidth)/ratio);
 
 $("#imgClass").css("height",currentClassImgHeight);
 }else  if(parseInt(originalClassImgWidth) <parseInt(originalClassImgHeight)){
	 var ratio=parseInt(originalClassImgHeight)/parseInt(originalClassImgWidth);
 
 currentClassImgHeight=Math.round(parseInt(currentClassImgWidth)*ratio);
 
 $("#imgClass").css("height",currentClassImgHeight); 
 }
 }
 
 
 
  var setImgLaboratory=document.querySelector("#imgLaboratory");
 var originalLaboratoryImgWidth=setImgLaboratory.naturalWidth;
 var currentLaboratoryImgWidth=setImgLaboratory.clientWidth;
 var originalLaboratoryImgHeight=setImgLaboratory.naturalHeight;
 var currentLaboratoryImgHeight=setImgLaboratory.clientHeight;
  
 if(parseInt(currentLaboratoryImgHeight) >0){
 if(parseInt(originalLaboratoryImgWidth) >parseInt(originalLaboratoryImgHeight)){
	 var ratio=parseInt(originalLaboratoryImgWidth)/parseInt(originalLaboratoryImgHeight);
 
 currentLaboratoryImgHeight=Math.round(parseInt(currentLaboratoryImgWidth)/ratio);
 
 $("#imgLaboratory").css("height",currentLaboratoryImgHeight);
 }else  if(parseInt(originalLaboratoryImgWidth) <parseInt(originalLaboratoryImgHeight)){
	 var ratio=parseInt(originalLaboratoryImgHeight)/parseInt(originalLaboratoryImgWidth);
 
 currentLaboratoryImgHeight=Math.round(parseInt(currentLaboratoryImgWidth)*ratio);
 
 $("#imgLaboratory").css("height",currentLaboratoryImgHeight); 
 }
 }
 
 
 
   var setImgSports=document.querySelector("#imgSports");
 var originalSportsImgWidth=setImgSports.naturalWidth;
 var currentSportsImgWidth=setImgSports.clientWidth;
 var originalSportsImgHeight=setImgSports.naturalHeight;
 var currentSportsImgHeight=setImgSports.clientHeight;
  
 if(parseInt(currentSportsImgHeight) >0){
 if(parseInt(originalSportsImgWidth) >parseInt(originalSportsImgHeight)){
	 var ratio=parseInt(originalSportsImgWidth)/parseInt(originalSportsImgHeight);
 
 currentSportsImgHeight=Math.round(parseInt(currentSportsImgWidth)/ratio);
 
 $("#imgSports").css("height",currentSportsImgHeight);
 }else  if(parseInt(originalSportsImgWidth) <parseInt(originalSportsImgHeight)){
	 var ratio=parseInt(originalSportsImgHeight)/parseInt(originalSportsImgWidth);
 
 currentSportsImgHeight=Math.round(parseInt(currentSportsImgWidth)*ratio);
 
 $("#imgSports").css("height",currentSportsImgHeight); 
 }
 }
 
 
  var setImgHomeOne=document.querySelector("#imgHomeOne");
 var originalHomeOneImgWidth=setImgHomeOne.naturalWidth;
 var currentHomeOneImgWidth=setImgHomeOne.clientWidth;
 var originalHomeOneImgHeight=setImgHomeOne.naturalHeight;
 var currentHomeOneImgHeight=setImgHomeOne.clientHeight;
  
 if(parseInt(currentHomeOneImgHeight) >0){
 if(parseInt(originalHomeOneImgWidth) >parseInt(originalHomeOneImgHeight)){
	 var ratio=parseInt(originalHomeOneImgWidth)/parseInt(originalHomeOneImgHeight);
 
 currentHomeOneImgHeight=Math.round(parseInt(currentHomeOneImgWidth)/ratio);
 
 $("#imgHomeOne").css("height",currentHomeOneImgHeight);
 }else  if(parseInt(originalHomeOneImgWidth) <parseInt(originalHomeOneImgHeight)){
	 var ratio=parseInt(originalHomeOneImgHeight)/parseInt(originalHomeOneImgWidth);
 
 currentHomeOneImgHeight=Math.round(parseInt(currentHomeOneImgWidth)*ratio);
 
 $("#imgHomeOne").css("height",currentHomeOneImgHeight); 
 }
 }
 
   var setImgEventsGallery=document.querySelector("#imgEventsGallery");
 var originalEventsGalleryOneImgWidth=setImgEventsGallery.naturalWidth;
 var currentEventsGalleryOneImgWidth=setImgEventsGallery.clientWidth;
 var originalEventsGalleryOneImgHeight=setImgEventsGallery.naturalHeight;
 var currentEventsGalleryOneImgHeight=setImgEventsGallery.clientHeight;
  
 if(parseInt(currentEventsGalleryOneImgHeight) >0){
 if(parseInt(originalEventsGalleryOneImgWidth) >parseInt(originalEventsGalleryOneImgHeight)){
	 var ratio=parseInt(originalEventsGalleryOneImgWidth)/parseInt(originalEventsGalleryOneImgHeight);
 
 currentEventsGalleryOneImgHeight=Math.round(parseInt(currentEventsGalleryOneImgWidth)/ratio);
 
 $("#imgEventsGallery").css("height",currentEventsGalleryOneImgHeight);
 }else  if(parseInt(originalEventsGalleryOneImgWidth) <parseInt(originalEventsGalleryOneImgHeight)){
	 var ratio=parseInt(originalEventsGalleryOneImgHeight)/parseInt(originalEventsGalleryOneImgWidth);
 
 currentEventsGalleryOneImgHeight=Math.round(parseInt(currentEventsGalleryOneImgWidth)*ratio);
 
 $("#imgEventsGallery").css("height",currentEventsGalleryOneImgHeight); 
 }
 }
 
 
 },1000);
 
 
 
}
function loadNews(str) {
 
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("selectNewsDetails").innerHTML =this.responseText;
		
		var newLink=document.getElementById("selectNews");
   newLink.style.display="none";
    var eventsGallery=document.getElementById("selectNewsDetails");
   eventsGallery.style.display="block";
		
      }
    };
    xmlhttp.open("GET","../admins/pickedNewsDetails.php?q="+str,true);
    xmlhttp.send();
	 
}
function loadEvents(str) {
 
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("picsgallery").innerHTML =this.responseText;
		
      }
    };
    xmlhttp.open("GET","../admins/pickedEventsGallery.php?q="+str,true);
    xmlhttp.send();
	 
}
function butNewsOptionsStart() {
 
     var newLink=document.getElementById("selectNews");
   newLink.style.display="block";
    var eventsGallery=document.getElementById("selectNewsDetails");
   eventsGallery.style.display="none";
    
}
  